package application;

public class AllMonsters {
	
	Results[] results;

}