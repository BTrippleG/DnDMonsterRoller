package application;

public class Results {

	public String slug;
	public String name;
	public String size;
	public String type;
	public String alignment;
	public String armor_class;
	public String armor_desc;
	public String hit_dice;
	public String damage_resistances;
	public String damage_immunities;
	public String hit_points;
	public String strength;
	public String dexterity;
	public String constitution;
	public String intelligence;
	public String wisdom;
	public String charisma;
	public String perception;

}